﻿using System;
using System.Collections.Generic;
using System.Text;
using TMS.Data.CustomTypes;
using TMS.Data.Dto.Interfaces;

namespace TMS.Data.Dto.DTOs
{
    public class TripDetailDto : TripDetailDtoRequiredInfo, ITripDetail
    {        
        public string From { get; set; }
        public int Gst { get; set; }
        public int NumOfPassengers { get; set; }
        public string To { get; set; }
        public int TotalAmount { get; set; }
        public int TripAmount { get; set; }
        public DateTime TripDate { get; set; }
        public string CustomerName { get; set; }
        public string EmployeeName { get; set; }

        public long TripDetailId { get; set; }        
    }
}
