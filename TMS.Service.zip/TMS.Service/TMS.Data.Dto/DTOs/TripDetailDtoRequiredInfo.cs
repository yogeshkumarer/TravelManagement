﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TMS.Data.Dto.DTOs
{
    public class TripDetailDtoRequiredInfo
    {
        public string CustomerPhoneNumber { get; set; }

        public string EmployeePhoneNumber { get; set; }
    }
}
