﻿using System;
using System.Collections.Generic;
using System.Text;
using TMS.Data.CustomTypes;
using TMS.Data.Dto.Interfaces;

namespace TMS.Data.Dto.DTOs
{
    public class CustomerDto : ICustomer
    {
        public DateTime DateOfBirth { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public GenderType Gender { get; set; }
        public string IdDetail { get; set; }
        public IdType IdType { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }

        public long CustomerId { get; set; }
    }
}
