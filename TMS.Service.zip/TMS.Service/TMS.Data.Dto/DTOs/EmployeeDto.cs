﻿using System;
using System.Collections.Generic;
using System.Text;
using TMS.Data.Dto.Interfaces;

namespace TMS.Data.Dto.DTOs
{
    public class EmployeeDto : IEmployee
    {
        public DateTime DateOfBirth { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
        public string VehicleNumber { get; set; }

        public long EmployeeId { get; set; }
    }
}
