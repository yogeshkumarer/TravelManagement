﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TMS.Data.Dto.Interfaces
{
    public interface ITripDetail
    {
        string From { get; set; }
        int Gst { get; set; }
        int NumOfPassengers { get; set; }
        string To { get; set; }
        int TotalAmount { get; set; }
        int TripAmount { get; set; }
        DateTime TripDate { get; set; }
        long TripDetailId { get; }
    }
}
