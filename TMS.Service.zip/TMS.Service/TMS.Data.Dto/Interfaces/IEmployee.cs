﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TMS.Data.Dto.Interfaces
{
    public interface IEmployee
    {
        DateTime DateOfBirth { get; set; }
        string Email { get; set; }
        string FirstName { get; set; }
        string LastName { get; set; }
        string PhoneNumber { get; set; }
        string VehicleNumber { get; set; }
        long EmployeeId { get; }
    }
}
