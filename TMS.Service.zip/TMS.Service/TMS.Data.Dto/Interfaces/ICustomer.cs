﻿using System;
using System.Collections.Generic;
using System.Text;
using TMS.Data.CustomTypes;

namespace TMS.Data.Dto.Interfaces
{
    public interface ICustomer
    {
        DateTime DateOfBirth { get; set; }
        string Email { get; set; }
        string FirstName { get; set; }
        GenderType Gender { get; set; }
        string IdDetail { get; set; }
        IdType IdType { get; set; }
        string LastName { get; set; }
        string PhoneNumber { get; set; }
        long CustomerId { get; }
    }
}
