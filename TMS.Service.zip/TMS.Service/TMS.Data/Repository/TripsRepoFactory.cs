﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TMS.Data.Entities;

namespace TMS.Data.Repository
{
    public class TripsRepoFactory : ITripsRepoFactory
    {
        private readonly TravelContext repositoryContext;

        public TripsRepoFactory(TravelContext repositoryContext)
        {
            this.repositoryContext = repositoryContext;
        }

        public TripDetailRepositoryBase GetTripsRepository(bool isAdminEmployee)
        {           
            if (isAdminEmployee)
            {
                return new AdminTripsRepository(repositoryContext);                
            }

            return new EmployeeTripsRepository(repositoryContext);
        }
    }
}
