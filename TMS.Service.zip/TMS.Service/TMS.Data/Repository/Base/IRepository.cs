﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using TMS.Data.Entities.Base;

namespace TMS.Data.Repository
{
    public interface IRepository<TEntity> where TEntity : IEntity
    {
        IList<TEntity> Get(Expression<Func<TEntity, bool>> expression);
        TEntity Get(long id);
        void Add(TEntity entity);
        void Update(TEntity entity);
        void Delete(TEntity entity);
    }
}
