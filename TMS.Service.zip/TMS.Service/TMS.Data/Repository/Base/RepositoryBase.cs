﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using TMS.Data.Entities;
using TMS.Data.Entities.Base;

namespace TMS.Data.Repository
{
    public abstract class RepositoryBase<TEntity> : IRepository<TEntity> where TEntity : class, IEntity
    {
        protected TravelContext RepositoryContext { get; set; }

        public RepositoryBase(TravelContext repositoryContext)
        {
            this.RepositoryContext = repositoryContext;
        }

        public virtual TEntity Get(long id)
        {
            return this.RepositoryContext.Set<TEntity>().FirstOrDefault(e => e.Id == id);
        }

        public virtual IList<TEntity> Get(Expression<Func<TEntity, bool>> expression)
        {
            return this.RepositoryContext.Set<TEntity>().Where(expression).ToList();
        }

        public void Add(TEntity entity)
        {
            this.RepositoryContext.Set<TEntity>().Add(entity);
            this.RepositoryContext.SaveChanges();
        }

        public virtual void Update(TEntity entity)
        {
            this.RepositoryContext.Set<TEntity>().Attach(entity);
            this.RepositoryContext.Entry(entity).State = EntityState.Modified;
            this.RepositoryContext.SaveChanges();
        }

        public void Delete(TEntity entity)
        {
            this.RepositoryContext.Set<TEntity>().Attach(entity);
            this.RepositoryContext.Entry(entity).State = EntityState.Deleted;
            this.RepositoryContext.SaveChanges();
        }
    }

}
