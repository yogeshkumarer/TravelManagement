﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using TMS.Data.CustomTypes;
using TMS.Data.Dto.DTOs;
using TMS.Data.Entities;
using TMS.Data.Entities.Entity;

namespace TMS.Data.Repository
{
    public abstract class TripDetailRepositoryBase : RepositoryBase<TripDetail>
    {
        protected EmployeeType EmployeeType;

        protected TripDetailRepositoryBase(TravelContext repositoryContext, EmployeeType employeeType)
            : base(repositoryContext)
        {
            this.EmployeeType = employeeType;
        }

        public override TripDetail Get(long id)
        {
            return this.RepositoryContext.Set<TripDetail>().FirstOrDefault(e => e.Id == id);
        }

        public override IList<TripDetail> Get(Expression<Func<TripDetail, bool>> expression)
        {
            return this.RepositoryContext.Set<TripDetail>().Where(expression).Where(e => e.Employee.EmployeeType == this.EmployeeType).ToList();
        }

        public virtual IList<TripDetail> GetAllTripsForEmployee(long employeeId, string mobileNumber = null)
        {
            if (employeeId != default(long))
            {
                return this.RepositoryContext.Set<TripDetail>().Where(e => e.EmployeeRefId == employeeId).ToList();
            }

            return this.RepositoryContext.Set<TripDetail>().Where(e => e.Employee.PhoneNumber == mobileNumber).ToList();
        }

        public virtual IList<TripDetail> GetAllTripsForCustomer(long customerId)
        {
            return this.RepositoryContext.Set<TripDetail>().Where(e => e.CustomerRefId == customerId).ToList();
        }

        public virtual void Add(TripDetail entity, TripDetailDtoRequiredInfo tripDetailDtoRequiredInfo)
        {
            SetAdditionalDetail(entity, tripDetailDtoRequiredInfo);

            base.Add(entity);
        }        

        public void Update(TripDetail entity, TripDetailDtoRequiredInfo tripDetailDtoRequiredInfo)
        {
            SetAdditionalDetail(entity, tripDetailDtoRequiredInfo); 

            base.Update(entity);
        }

        private void SetAdditionalDetail(TripDetail entity, TripDetailDtoRequiredInfo tripDetailDtoRequiredInfo)
        {
            entity.Employee = this.RepositoryContext.Set<Employee>().Single(e => e.PhoneNumber == tripDetailDtoRequiredInfo.EmployeePhoneNumber);
            entity.EmployeeRefId = entity.Employee.Id;
            entity.CustomerRefId = this.RepositoryContext.Set<Customer>().Single(e => e.PhoneNumber == tripDetailDtoRequiredInfo.CustomerPhoneNumber).Id;
        }
    }
}
