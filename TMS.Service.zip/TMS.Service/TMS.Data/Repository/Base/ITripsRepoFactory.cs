﻿using System.Threading.Tasks;

namespace TMS.Data.Repository
{
    public interface ITripsRepoFactory
    {
        TripDetailRepositoryBase GetTripsRepository(bool isAdminEmployee);
    }
}
