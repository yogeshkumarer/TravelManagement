﻿using System;
using System.Collections.Generic;
using System.Text;
using TMS.Data.Entities;
using TMS.Data.Entities.Entity;

namespace TMS.Data.Repository
{
    public class EmployeeRepository : RepositoryBase<Employee>
    {
        public EmployeeRepository(TravelContext repositoryContext)
            : base(repositoryContext)
        {
        }
    }
}
