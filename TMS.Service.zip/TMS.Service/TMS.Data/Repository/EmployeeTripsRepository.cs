﻿using System;
using System.Collections.Generic;
using System.Text;
using TMS.Data.CustomTypes;
using TMS.Data.Entities;
using TMS.Data.Entities.Entity;

namespace TMS.Data.Repository
{
    public class EmployeeTripsRepository : TripDetailRepositoryBase
    {
        public EmployeeTripsRepository(TravelContext repositoryContext)
            : base(repositoryContext, EmployeeType.Admin)
        {            
        }
    }
}
