﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TMS.Data.CustomTypes;
using TMS.Data.Entities;
using TMS.Data.Entities.Entity;

namespace TMS.Data.Repository
{
    public class AdminTripsRepository : TripDetailRepositoryBase
    {
        public AdminTripsRepository(TravelContext repositoryContext)
            : base(repositoryContext, EmployeeType.Admin)
        {
        }

        public override IList<TripDetail> GetAllTripsForEmployee(long employeeId, string mobileNumber = null)
        {
            return this.RepositoryContext.Set<TripDetail>().ToList();
        }
    }
}
