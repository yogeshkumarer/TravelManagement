﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TMS.Data.CustomTypes
{
    public enum IdType
    {
        Aadhar = 0,
        DrivingLicense = 1,
        Pan = 2
    }
}
