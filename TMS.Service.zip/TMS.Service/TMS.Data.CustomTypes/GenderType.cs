﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TMS.Data.CustomTypes
{
    public enum GenderType
    {
        Male = 0,
        Female = 1,
        Other = 2
    }
}
