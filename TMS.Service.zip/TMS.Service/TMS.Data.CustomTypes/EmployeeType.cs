﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TMS.Data.CustomTypes
{
    public enum EmployeeType
    {
        Employee = 1,
        Admin = 2
    }
}
