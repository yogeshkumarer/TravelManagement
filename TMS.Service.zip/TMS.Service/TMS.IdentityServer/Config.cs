﻿// Copyright (c) Brock Allen & Dominick Baier. All rights reserved.
// Licensed under the Apache License, Version 2.0. See LICENSE in the project root for license information.


using IdentityServer4;
using IdentityServer4.Models;
using IdentityServer4.Test;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.IO;
using System.Security.Claims;

namespace TMS.IdentityServer
{
    public static class Config
    {
        public static string ApiName = "TMS.API.Identity";

        public static List<TestUser> GetUsers()
        {
            var users = new List<TestUser>();

            foreach (var item in JArray.Parse(File.ReadAllText(@"test-users.json")))
            {
                var username = item.SelectToken("username").ToString();

                var testUser = new TestUser
                {
                    SubjectId = item.SelectToken("subjectId").ToString(),
                    IsActive = item.SelectToken("isActive").ToObject<bool>(),
                    Username = username,
                    Password = item.SelectToken("password").ToString(),
                    Claims = new[]
                    {
                        new Claim("username", username),
                        new Claim("userrole", item.SelectToken("role").ToString()),
                        new Claim("mobile", item.SelectToken("mobile").ToString())
                    }
                };

                users.Add(testUser);
            }

            return users;
        }

        public static IEnumerable<IdentityResource> GetIdentityResources()
        {
            return new List<IdentityResource>
            {
                new IdentityResources.OpenId(),
                new IdentityResources.Profile(),
            };
        }

        public static IEnumerable<ApiResource> GetApis()
        {
            return new List<ApiResource>
            {
                new ApiResource(ApiName, "TMS API", new List<string>{ "username", "userrole", "mobile" })
            };
        }

        public static IEnumerable<Client> GetClients()
        {
            return new List<Client>
            {
                // JavaScript Client
                new Client
                {
                    ClientId = "tms-js",
                    ClientName = "JavaScript Client",
                    AllowedGrantTypes = GrantTypes.Implicit,
                    RequirePkce = false,
                    RequireClientSecret = false,
                    AccessTokenLifetime = 86400000,
                    AllowAccessTokensViaBrowser = true,
                    RequireConsent = false,

                    RedirectUris =           { "https://localhost:44384/signin-oidc", "http://localhost:44384/signin-oidc", "http://localhost:8080/auth-callback" },
                    PostLogoutRedirectUris = {"http://localhost:8080/"},
                    AllowedCorsOrigins = { "http://localhost:8080/" },

                    AllowedScopes =
                    {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.Profile,
                        ApiName
                    }
                }
            };
        }
    }
}