﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using System;
using System.Threading;
using TMS.Data.CustomTypes;
using TMS.Data.Entities.Base;
using TMS.Data.Entities.Entity;

namespace TMS.Data.Entities
{
    public class TravelContext : DbContext
    {
        public TravelContext(DbContextOptions options)
            : base(options)
        {            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>().Property(x => x.EmployeeType).HasDefaultValue(EmployeeType.Employee);

            modelBuilder.Entity<Employee>().Property(e => e.EmployeeType).HasConversion<string>();

            modelBuilder.Entity<Customer>().Property(e => e.IdType).HasConversion<string>();

            modelBuilder.Entity<Customer>().Property(e => e.Gender).HasConversion<string>();

            base.OnModelCreating(modelBuilder);
        }

        public override int SaveChanges()
        {
            foreach (var auditableEntity in ChangeTracker.Entries<IAuditDetail>())
            {
                if (auditableEntity.State == EntityState.Added ||
                    auditableEntity.State == EntityState.Modified)
                {
                    //auditableEntity.Entity.ModifiedBy = Thread.CurrentPrincipal.Identity.Name;
                    auditableEntity.Entity.ModifiedBy = "TEST USER";
                    auditableEntity.Entity.ModifiedDate = DateTime.Now;

                    if (auditableEntity.State == EntityState.Added)
                    {
                        auditableEntity.Entity.CreatedBy = "TEST USER";
                        auditableEntity.Entity.CreatedDate = DateTime.Now;
                    }
                }
            }

            return base.SaveChanges();
        }

        public void SetUserName(string userName)
        {

        }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<TripDetail> TripDetail { get; set; }
    }
}
