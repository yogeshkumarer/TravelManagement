﻿namespace TMS.Data.Entities.Base
{
    public interface IEntity : IKey, IAuditDetail
    {
    }
}
