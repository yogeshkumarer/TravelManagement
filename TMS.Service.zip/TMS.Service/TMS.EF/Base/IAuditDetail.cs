﻿using System;

namespace TMS.Data.Entities.Base
{
    public interface IAuditDetail
    {
        string ModifiedBy { get; set; }

        DateTime ModifiedDate { get; set; }

        string CreatedBy { get; set; }

        DateTime CreatedDate { get; set; }
    }
}
