﻿namespace TMS.Data.Entities.Base
{
    public interface IKey
    {
        long Id { get; set; }
    }
}
