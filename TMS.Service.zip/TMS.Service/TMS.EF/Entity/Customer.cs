﻿using Microsoft.EntityFrameworkCore.Infrastructure;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
using TMS.Data.CustomTypes;
using TMS.Data.Dto.Interfaces;
using TMS.Data.Entities.Base;

namespace TMS.Data.Entities.Entity
{
    public class Customer : BaseEntity, ICustomer
    {
        private ICollection<TripDetail> trips;
        private ILazyLoader LazyLoader { get; set; }

        public Customer()
        {
        }

        private Customer(ILazyLoader lazyLoader)
        {
            LazyLoader = lazyLoader;
        }

        [Required(ErrorMessage = "FirstName is required")]
        [StringLength(30, ErrorMessage = "FirstName can't be longer than 60 characters")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "LastName is required")]
        [StringLength(30, ErrorMessage = "LastName can't be longer than 60 characters")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Date of birth is required")]
        public DateTime DateOfBirth { get; set; }

        [Required(ErrorMessage = "Phone number is required")]
        public string PhoneNumber { get; set; }

        public string Email { get; set; }

        [Required(ErrorMessage = "ID type is required")]
        [Column(TypeName = "nvarchar(24)")]
        public IdType IdType { get; set; }

        [Required(ErrorMessage = "ID detail is required")]
        public string IdDetail { get; set; }

        [Required(ErrorMessage = "Gender is required")]
        [Column(TypeName = "nvarchar(24)")]
        public GenderType Gender { get; set; }

        //public virtual ICollection<TripDetail> Trips { get; set; }
        public ICollection<TripDetail> Trips
        {
            get => LazyLoader.Load(this, ref trips);
            set => trips = value;
        }

        public long CustomerId => this.Id;
    }
}
