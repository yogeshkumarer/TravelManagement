﻿using Microsoft.EntityFrameworkCore.Infrastructure;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using TMS.Data.CustomTypes;
using TMS.Data.Dto.Interfaces;
using TMS.Data.Entities.Base;

namespace TMS.Data.Entities.Entity
{
    public class Employee : BaseEntity, IEmployee
    {
        private ICollection<TripDetail> trips;
        private ILazyLoader LazyLoader { get; set; }

        public Employee()
        {
        }

        private Employee(ILazyLoader lazyLoader)
        {
            LazyLoader = lazyLoader;
        }

        [Required(ErrorMessage = "FirstName is required")]
        [StringLength(30, ErrorMessage = "FirstName can't be longer than 60 characters")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "LastName is required")]
        [StringLength(30, ErrorMessage = "LastName can't be longer than 60 characters")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Date of birth is required")]
        public DateTime DateOfBirth { get; set; }

        [Required(ErrorMessage = "Phone number is required")]
        public string PhoneNumber { get; set; }
        public string Email { get; set; }

        [Required(ErrorMessage = "Vehicle detail is required")]        
        public string VehicleNumber { get; set; }

        [Required(ErrorMessage = "Employee type is required")]
        [Column(TypeName = "nvarchar(24)")]
        public EmployeeType EmployeeType { get; set; }

        //public virtual ICollection<TripDetail> Trips { get; set; }
        public ICollection<TripDetail> Trips
        {
            get => LazyLoader.Load(this, ref trips);
            set => trips = value;
        }

        public long EmployeeId => this.Id;
    }
}
