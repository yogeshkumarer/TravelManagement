﻿using Microsoft.EntityFrameworkCore.Infrastructure;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
using TMS.Data.Dto.Interfaces;
using TMS.Data.Entities.Base;

namespace TMS.Data.Entities.Entity
{
    public class TripDetail : BaseEntity, ITripDetail
    {
        private Employee employee;
        private Customer customer;
        private ILazyLoader LazyLoader { get; set; }

        public TripDetail()
        {
        }

        private TripDetail(ILazyLoader lazyLoader)
        {
            LazyLoader = lazyLoader;
        }

        [Required(ErrorMessage = "Trip Date is required")]
        public DateTime TripDate { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public int TripAmount { get; set; }
        public int Gst { get; set; }
        public int TotalAmount { get; set; }
        public int NumOfPassengers { get; set; }

        [ForeignKey("Employee")]
        public long EmployeeRefId { get; set; }
        //public virtual Employee Employee { get; set; }
        public Employee Employee
        {
            get => LazyLoader.Load(this, ref employee);
            set => employee = value;
        }

        [ForeignKey("Customer")]
        public long CustomerRefId { get; set; }
        //public virtual Customer Customer { get; set; }
        public Customer Customer
        {
            get => LazyLoader.Load(this, ref customer);
            set => customer = value;
        }

        public long TripDetailId => this.Id;
    }
}
