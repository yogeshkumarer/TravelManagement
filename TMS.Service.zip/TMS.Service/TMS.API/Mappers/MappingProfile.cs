﻿using AutoMapper;

using TMS.Data.Dto.DTOs;
using TMS.Data.Entities.Entity;

namespace TMS.API.TripDetails.Mappers
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<TripDetail, TripDetailDto>()
                .ForMember(dest => dest.CustomerPhoneNumber, opts => opts.Ignore())
                .ForMember(dest => dest.EmployeePhoneNumber, opts => opts.Ignore())
                .ForMember(dest => dest.CustomerName, opts => opts.MapFrom(src => $"{ src.Customer.FirstName } { src.Customer.LastName }"))
                .ForMember(dest => dest.EmployeeName, opts => opts.MapFrom(src => $"{ src.Employee.FirstName } { src.Employee.LastName }"));

            CreateMap<TripDetailDto, TripDetail>()
                    .ForMember(dest => dest.Id, opts => opts.MapFrom(src => src.TripDetailId))
                    .ForMember(dest => dest.Employee, opts => opts.Ignore())
                    .ForMember(dest => dest.CreatedBy, opts => opts.Ignore())
                    .ForMember(dest => dest.CreatedDate, opts => opts.Ignore())
                    .ForMember(dest => dest.ModifiedBy, opts => opts.Ignore())
                    .ForMember(dest => dest.ModifiedDate, opts => opts.Ignore())
                    .ForMember(dest => dest.EmployeeRefId, opts => opts.Ignore())
                    .ForMember(dest => dest.CustomerRefId, opts => opts.Ignore())
                    .ForMember(dest => dest.Customer, opts => opts.Ignore());

            CreateMap<TripDetailDto, TripDetailDtoRequiredInfo>();
        }
    }
}
