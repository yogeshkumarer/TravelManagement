﻿using AutoMapper;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Cors.Internal;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using TMS.API.TripDetails.ExceptionHandling;
using TMS.API.TripDetails.Mappers;
using TMS.Data.Entities;
using TMS.Data.Repository;

namespace TMS.API.TripDetails
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddScoped<ITripsRepoFactory, TripsRepoFactory>();

            services.AddMemoryCache();

            services.AddSingleton<IMapper>(AutoMapperConfig.CreateMapper());

            services.AddMvc()
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_2)
                .ConfigureApiBehaviorOptions(options =>
                {
                });

            services.AddDbContext<TravelContext>(opts =>
                opts.UseSqlServer(Configuration["ConnectionString:TravelManagementDB"]));

            services.AddAuthentication("Bearer")
                .AddJwtBearer("Bearer", options =>
                {
                    options.Authority = "https://localhost:44386/";
                    options.RequireHttpsMetadata = false;

                    options.Audience = "TMS.API.Identity";
                });

            services.AddCors(options =>
            {
                options.AddPolicy("TmsCorsPolicy",
                builder =>
                {
                    builder.WithOrigins("http://localhost:8080").AllowAnyHeader().AllowAnyMethod();
                });
            });

            services.Configure<MvcOptions>(options =>
            {
                options.Filters.Add(new CorsAuthorizationFilterFactory("TmsCorsPolicy"));
            });

            services.AddAntiforgery(options =>
            {
            });

            services.AddAuthorization(options =>
            {
                options.AddPolicy("AdminPolicy", policy => policy.RequireClaim("userrole", "admin"));
                options.AddPolicy("EmployeePolicy", policy => policy.RequireClaim("userrole", "employee"));
                options.AddPolicy("AdminEmployeePolicy", policy => policy.RequireClaim("userrole", "employee", "admin"));
                options.AddPolicy("CustomerPolicy", policy => policy.RequireClaim("userrole", "customer"));
            });
        }        

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, IAntiforgery antiforgery)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.Use(next => context =>
            {
                string path = context.Request.Path.Value;
                var tokens = antiforgery.GetAndStoreTokens(context);
                context.Response.Cookies.Append("XSRF-TOKEN", tokens.RequestToken,
                     new CookieOptions()
                     {
                         HttpOnly = false
                     });
                return next(context);
            });

            app.ConfigureExceptionHandler();

            app.UseAuthentication();

            app.UseCors("TmsCorsPolicy");

            app.UseMvc();
        }
    }
}
