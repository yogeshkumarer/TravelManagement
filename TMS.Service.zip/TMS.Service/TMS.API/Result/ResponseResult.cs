﻿using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace TMS.API.TripDetails.Result
{
    public class ResponseResult : ObjectResult
    {
        public ResponseResult(HttpStatusCode statusCode, object value = null) : base(value)
        {
            this.StatusCode = (int)statusCode;
        }

        public bool IsSuccessStatusCode
        {
            get
            {
                return this.StatusCode.HasValue && this.StatusCode.Value >= 200 && this.StatusCode.Value <= 299; 
            }
        }
    }
}
