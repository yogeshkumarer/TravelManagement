﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TMS.API.TripDetails.Result;
using TMS.Data.Dto.DTOs;
using TMS.Data.Entities.Entity;
using TMS.Data.Repository;

namespace TMS.API.TripDetails.Controllers
{
    [EnableCors("TmsCorsPolicy")]
    [ApiController]
    [ApiVersion("1.0")]
    public class TripDetailsController : ControllerBase
    {
        private readonly ITripsRepoFactory tripsRepoFactory;
        private readonly IMapper mapper;

        public TripDetailsController(ITripsRepoFactory tripsRepoFactory, IMapper mapper)
        {
            this.tripsRepoFactory = tripsRepoFactory;
            this.mapper = mapper;
        }

        [Authorize(Policy = "AdminEmployeePolicy")]
        [Route("api/trips")]
        [HttpGet]        
        public ResponseResult Get()
        {
            var roleClaim = HttpContext.User.Claims.FirstOrDefault(x => x.Type == "userrole");

            var tripsRepo = tripsRepoFactory.GetTripsRepository(roleClaim != null && roleClaim.Value == "admin");
            var trips = tripsRepo.GetAllTripsForEmployee(0);                      

            if (trips == null || trips.Count == 0)
            {
                return new ResponseResult(System.Net.HttpStatusCode.NoContent);
            }

            return new ResponseResult(System.Net.HttpStatusCode.OK, mapper.Map<IList<TripDetailDto>>(trips));
        }

        [Authorize(Policy = "AdminEmployeePolicy")]
        [Route("api/trips/{id}/{mobile}")]
        [Route("api/trips/{mobile}")]
        [HttpGet]
        public ResponseResult Get(long id, string mobile = null)
        {
            string mobileNumber = null;
            if (!string.IsNullOrEmpty(mobile))
            {
                byte[] data = Convert.FromBase64String(mobile);
                mobileNumber = Encoding.UTF8.GetString(data);
            }

            var roleClaim = HttpContext.User.Claims.FirstOrDefault(x => x.Type == "userrole");
            var tripsRepo = tripsRepoFactory.GetTripsRepository(roleClaim != null && roleClaim.Value == "admin");
            var trips = tripsRepo.GetAllTripsForEmployee(id, mobileNumber);

            if (trips == null || trips.Count == 0)
            {
                return new ResponseResult(System.Net.HttpStatusCode.NoContent);
            }

            return new ResponseResult(System.Net.HttpStatusCode.OK, mapper.Map<IList<TripDetailDto>>(trips));
        }

        [Authorize(Policy = "CustomerPolicy")]
        [Route("api/trips/")]
        [HttpPost]       
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ResponseResult Post([FromBody] TripDetailDto tripDetailDto)
        {
            if (!ModelState.IsValid)
            {
                return new ResponseResult(System.Net.HttpStatusCode.BadRequest);
            }

            var roleClaim = HttpContext.User.Claims.FirstOrDefault(x => x.Type == "userrole");
            var tripRepository = tripsRepoFactory.GetTripsRepository(roleClaim != null && roleClaim.Value == "admin");

            var trip = mapper.Map<TripDetail>(tripDetailDto);
            var tripDetailDtoRequiredInfo = mapper.Map<TripDetailDtoRequiredInfo>(tripDetailDto);

            var existingTrip = tripRepository.Get(trip.Id);
            if (existingTrip == null)
            {
                tripRepository.Add(trip, tripDetailDtoRequiredInfo);
            }
            else
            {
                tripRepository.Update(trip, tripDetailDtoRequiredInfo);
            }

            return new ResponseResult(System.Net.HttpStatusCode.Created, tripDetailDto);
        }
    }
}
